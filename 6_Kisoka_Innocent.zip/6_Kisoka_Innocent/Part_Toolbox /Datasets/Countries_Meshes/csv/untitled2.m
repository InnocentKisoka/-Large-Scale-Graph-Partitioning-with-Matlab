function read_csv_graphs(filename)
    % Read the CSV file
    data = readtable(filename);

    % Extract node indices and construct the adjacency matrix
    edges = [data.Var1, data.Var2];
    G = graph(edges(:, 1), edges(:, 2));

    % Extract node coordinates (assuming a separate CSV file for coordinates)
    % Replace 'coordinates_filename.csv' with the actual filename
    coord_data = readtable('coordinates_filename.csv');
    pos = [coord_data.Var1, coord_data.Var2];

    % Convert the graph to an adjacency matrix
    A = adjacency(G);

    % Visualize the graph
    gplot(A, pos);

    % Save the adjacency matrix and coordinates
    save('adjacency_matrix.mat', 'A');
    save('node_coordinates.mat', 'pos');

    % Return the adjacency matrix and node coordinates
    return A, pos;
end