function [part1, part2] = bisection_coordinate(A, xy, picture)
    % bisection_coordinate : Perform coordinate bisection partition of a mesh.
disp(' HPC Lab at USI:   ');
disp(' Implement coordinate bisection');    %
    % Syntax:
    %   [part1, part2] = bisection_coordinate(A, xy, picture)
    %
    % Description:
    %   This function computes a partition of the graph described by the adjacency
    %   matrix A based on a bisection perpendicular to one of the coordinate axes.
    %   It evaluates each coordinate axis and selects the partition with the
    %   smallest cut size.
    %
    % Inputs:
    %   A       - Sparse adjacency matrix representing the graph (NxN).
    %   xy      - Matrix of node coordinates in d-dimensional space (NxD).
    %   picture - (Optional) Boolean flag to display the partition plot (1 to display, 0 to skip).
    %
    % Outputs:
    %   part1 - Indices of nodes in the first partition.
    %   part2 - Indices of nodes in the second partition.

    % Validate inputs
    if nargin < 3
        picture = 0; % Default to not displaying the plot
    end

    if ~issparse(A)
        error('Input A must be a sparse adjacency matrix.');
    end

    if size(A, 1) ~= size(A, 2)
        error('Adjacency matrix A must be square.');
    end

    if size(xy, 1) ~= size(A, 1)
        error('The number of rows in xy must match the number of nodes in A.');
    end

    % Initialize variables
    d = size(xy, 2); % Dimensionality of the coordinates
    best_cut = inf; % Best cut size found so far
    part1 = [];
    part2 = [];

    % Iterate over each dimension
    for dim = 1:d
        % Define a unit vector along the current dimension
        v = zeros(d, 1);
        v(dim) = 1;

        % Partition the graph based on the current dimension
        % Here, we assume the 'partition' function is defined elsewhere
        % and it returns the partition based on the given vector.
        [p1, p2] = partition(xy, v);

        % Compute the cut size for this partition
        this_cut = cutsize(A, p1);

        % Update the best partition if this cut is smaller
        if this_cut < best_cut
            best_cut = this_cut;
            part1 = p1;
            part2 = p2;
        end
    end

    % Plot the partition if requested
    if picture
        clf reset; % Clear the current figure
        % Ensure colors are valid RGB triplets
        color1 = [1, 0, 0]; % Red
        color2 = [0, 0, 1]; % Blue
        color3 = [0.5, 0.5, 0.5]; % Gray
        gplotpart(A, xy, part1, part2, color1, color2, color3); % Plot the partitions
        title('Coordinate Bisection');
    end
end 
