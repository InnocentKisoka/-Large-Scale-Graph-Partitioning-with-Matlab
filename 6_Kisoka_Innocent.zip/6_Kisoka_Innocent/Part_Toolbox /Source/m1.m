>> A = blkdiag(ones(5),ones(5));





