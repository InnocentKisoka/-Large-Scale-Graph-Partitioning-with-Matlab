% Benchmark for recursively partitioning meshes, based on various
% bisection approaches
%
% D.P & O.S for the "HPC Course" at USI and
%                   "HPC Lab for CSE" at ETH Zurich



% add necessary paths
addpaths_GP;
nlevels_a = 3;
nlevels_b = 4;

fprintf('       *********************************************\n')
fprintf('       ***  Recursive graph bisection benchmark  ***\n');
fprintf('       *********************************************\n')

% load cases
cases = {
    'airfoil1.mat';
    'netz4504_dual.mat';
    'stufe.mat';
    '3elt.mat';
    'barth4.mat';
    'ukerbe1.mat';
    'crack.mat';
    };

nc = length(cases);
maxlen = 0;
for c = 1:nc
    if length(cases{c}) > maxlen
        maxlen = length(cases{c});
    end
end

for c = 1:nc
    fprintf('.');
    sparse_matrices(c) = load(cases{c});
end


fprintf('\n\n Report Cases         Nodes     Edges\n');
fprintf(repmat('-', 1, 40));
fprintf('\n');
for c = 1:nc
    spacers  = repmat('.', 1, maxlen+3-length(cases{c}));
    [params] = Initialize_case(sparse_matrices(c));
    fprintf('%s %s %10d %10d\n', cases{c}, spacers,params.numberOfVertices,params.numberOfEdges);
end

%% Create results table
fprintf('\n%7s %16s %20s %16s %16s\n','Bisection','Spectral','Metis 5.0.2','Coordinate','Inertial');
fprintf('%10s %10d %6d %10d %6d %10d %6d %10d %6d\n','Partitions',8,16,8,16,8,16,8,16);
fprintf(repmat('-', 1, 100));
fprintf('\n');

set(gca,'Color','none');

for c = 1:nc
    fprintf('%s', cases{c});
    spacers = repmat('.', 1, maxlen+3-length(cases{c}));
    fprintf('%s %s', spacers);
    sparse_matrix = load(cases{c});
    

    % Recursively bisect the loaded graphs in 8 and 16 subgraphs.
    % Steps
    % 1. Initialize the problem

    p_values = [3,4];
    [params] = Initialize_case(sparse_matrices(c));
    W      = params.Adj;
    coords = params.coords;

    % 2. Recursive routines
    % i. Spectral    
    % ii. Metis
    % iii. Coordinate    
    % iv. Inertial
    % 3. Calculate number of cut edges
    % 4. Visualize the partitioning result

    data = zeros(length(p_values) * 4, 1); % 4 methods * p_values;
    count = 1;
    % Partitioning methods
    names = ["spectral", "metis", "coordinate", "inertial"];
    meths = {@bisection_spectral, @bisection_metis, @bisection_coordinate,@bisection_inertial};
    
    % Loop through methods and partition sizes
    for o = 1:length(meths)
        for p_idx = 1:length(p_values)
            p = p_values(p_idx)
            % Recursive bisection
            [m, s, A] = rec_bisection(meths{o}, p, W, coords, 0);
            % Calculate edge cuts
            [i,j] = find(W);
            f = find(m(i) > m(j));
            data(count) = length(f);
            
            count = count + 1;
             % Visualization for p = 16
            if p == 4 % Only visualize for 16 partitions
                figure(o + (c-1)*4); % Unique figure index
                gplotmap(W, coords, m);
                title(sprintf('%s Recursive Bisection for %s (p = %d)', names{o}, cases{c}, 2^p));
                saveas(gcf, sprintf('./%d_bisection_%s_%s.png', 2^p, names{o}, cases{c}));
            end
        end
    end
    
    
    
     % Print edge-cut results
    fprintf('%6d %6d %10d %6d %10d %6d %10d %6d\n', data(:));
    
end
