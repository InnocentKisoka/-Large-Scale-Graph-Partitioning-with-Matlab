function [part1, part2] = bisection_metis(A, xy, picture)
% METISPART : Partition a graph using Metis default method.
%
% [part1, part2] = bisection_metis(A, xy, picture) partitions the graph 
% represented by adjacency matrix A into two parts using Metis.
%
disp(' HPC Lab at USI:   ');
disp(' Implement metis bisection');
% Inputs:
%   A       - Adjacency matrix of the graph
%   xy      - Node coordinates (for visualization)
%   picture - Flag (1 or 0) to enable/disable visualization
%
% Outputs:
%   part1 - Indices of nodes in the first partition
%   part2 - Indices of nodes in the second partition
%
% Example:
%   [p1, p2] = bisection_metis(A, xy, 1);
%
% Dependencies:
%   Requires METIS and its MATLAB interface (metismex).

    % Check if METIS is installed
    if ~exist('metismex', 'file')
        error('METIS and its MATLAB interface (metismex) are not installed.');
    end

    % Perform bisection using METIS
    map = metismex('PartGraphRecursive', A, 2);

    % Split nodes into partitions
    [part1, part2] = other(map);

    % Optional: Visualize the partition if requested
    if picture
        gplotpart(A, xy, part1, part2);
        title('Metis bisection');
    end
end
