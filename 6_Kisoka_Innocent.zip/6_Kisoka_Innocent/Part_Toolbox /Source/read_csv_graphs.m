% Script to process Norway graph, visualize, and save the results

% Define file names for Norway adjacency and coordinates
norway_adj_file = 'NO-9935-adj.csv';
norway_coords_file = 'NO-9935-pts.csv';

% Read the adjacency matrix and coordinates (skip the header row)
edges = readmatrix(norway_adj_file, 'NumHeaderLines', 1);  % Skipping the first line (header) in the adjacency file
coords = readmatrix(norway_coords_file, 'NumHeaderLines', 1);  % Skipping the header in coordinates file

% Construct the adjacency matrix
n = max(max(edges)); % Find the number of nodes (maximum index)
W = sparse(edges(:,1), edges(:,2), 1, n, n); % Create sparse adjacency matrix
W = W + W'; % Ensure the matrix is symmetric

% Visualize the graph for Norway
figure;
gplotg(W, coords); % Use gplotg to visualize the graph
title('Graph of Norway');

% Ensure the output directory exists
output_dir = '';  % Directory to save the plot and files
if ~exist(output_dir, 'dir')  % Check if the directory exists
    mkdir(output_dir);  % Create the directory if it doesn't exist
end

% Save the plot as PNG
saveas(gcf, fullfile(output_dir, 'Norway_Graph.png'));  % Save the plot as PNG

% Save the adjacency matrix and coordinates as .mat files
save(fullfile(output_dir, 'Norway_Graph.mat'), 'W', 'coords');  % Save adjacency matrix and coordinates to .mat file

%% Process Vietnam
% Define file names for Norway adjacency and coordinates
vietnam_adj_file = 'VN-4031-adj.csv';
vietnam_coords_file = 'VN-4031-pts.csv';

% Read the adjacency matrix and coordinates (skip the header row)
edges = readmatrix(vietnam_adj_file, 'NumHeaderLines', 1);  % Skipping the first line (header) in the adjacency file
coords = readmatrix(vietnam_coords_file, 'NumHeaderLines', 1);  % Skipping the header in coordinates file


% Construct the adjacency matrix
n = max(max(edges)); % Find the number of nodes
W = sparse(edges(:, 1), edges(:, 2), 1, n, n); % Create sparse adjacency matrix
W = W + W'; % Ensure the matrix is symmetric

% Visualize the graph
figure;
gplotg(W, coords); % Use gplotg to visualize the graph
title('Graph of Vietnam');

% Save the visualization and data
saveas(gcf, fullfile(output_dir, 'Vietnam_Graph.png')); % Save as PNG
save(fullfile(output_dir, 'Vietnam_Graph.mat'), 'W', 'coords'); % Save as MAT
disp('Vietnam graph saved.');

disp('Processing complete.');



norway_adj_file = 'RU-40527-adj.csv';
norway_coords_file = 'RU-40527-pts.csv';

% Read the adjacency matrix and coordinates (skip the header row)
edges = readmatrix(norway_adj_file, 'NumHeaderLines', 1);  % Skipping the first line (header) in the adjacency file
coords = readmatrix(norway_coords_file, 'NumHeaderLines', 1);  % Skipping the header in coordinates file

% Construct the adjacency matrix
n = max(max(edges)); % Find the number of nodes (maximum index)
W = sparse(edges(:,1), edges(:,2), 1, n, n); % Create sparse adjacency matrix
W = W + W'; % Ensure the matrix is symmetric

% Visualize the graph for Norway
figure;
gplotg(W, coords); % Use gplotg to visualize the graph
title('Graph of Russia');

% Ensure the output directory exists
output_dir = '';  % Directory to save the plot and files
if ~exist(output_dir, 'dir')  % Check if the directory exists
    mkdir(output_dir);  % Create the directory if it doesn't exist
end

% Save the plot as PNG
saveas(gcf, fullfile(output_dir, 'Russia.png'));  % Save the plot as PNG

% Save the adjacency matrix and coordinates as .mat files
save(fullfile(output_dir, 'Russia_Graph.mat'), 'W', 'coords');  % Save adjacency matrix and coordinates to .mat file