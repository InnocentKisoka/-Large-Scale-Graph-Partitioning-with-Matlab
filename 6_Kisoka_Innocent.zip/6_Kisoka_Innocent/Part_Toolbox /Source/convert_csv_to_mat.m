function convert_csv_to_mat(adj_csv, pts_csv, output_file)
    % Convert adjacency and points CSV files into a .mat file compatible with Initialize_case.
    
    % Load adjacency data
    adj_data = readmatrix(adj_csv);
    if size(adj_data, 2) ~= 3
        error('Adjacency file must have 3 columns: source, destination, weight');
    end
    
    % Extract adjacency matrix information
    sources = adj_data(:, 1);
    destinations = adj_data(:, 2);
    weights = adj_data(:, 3);
    num_vertices = max(max(sources, destinations));
    
    % Create sparse adjacency matrix
    A = sparse(sources, destinations, weights, num_vertices, num_vertices);
    
    % Load points data (coordinates)
    coords = [];
    if ~isempty(pts_csv)
        coords_data = readmatrix(pts_csv);
        if size(coords_data, 2) ~= 2
            error('Points file must have 2 columns: x, y');
        end
        coords = coords_data;
    end
    
    % Save data in a structured format compatible with Initialize_case
    SM_case.Problem.A = A;
    if ~isempty(coords)
        SM_case.Problem.aux.coord = coords;
    end
    
    save(output_file, 'SM_case');
    fprintf('Saved data to %s\n', output_file);
end
