function handle = gplotpart(A, xy, part1, part2, color1, color2, color3)
    % GPLOTPART : Plot a partitioned graph in 2 or 3 dimensions.

    if nargin < 5
        color1 = [1, 0, 0]; % Default red
    end
    if nargin < 6
        color2 = [0, 0, 1]; % Default blue
    end
    if nargin < 7
        color3 = [0.5, 0.5, 0.5]; % Default gray
    end

    % Ensure color arguments are valid RGB triplets
    if length(color1) ~= 3 || any(color1 < 0) || any(color1 > 1)
        error('Invalid RGB triplet for color1');
    end
    if length(color2) ~= 3 || any(color2 < 0) || any(color2 > 1)
        error('Invalid RGB triplet for color2');
    end
    if length(color3) ~= 3 || any(color3 < 0) || any(color3 > 1)
        error('Invalid RGB triplet for color3');
    end
    

    [n,n] = size(A);
    part1 = part1(:);
    part2 = 1:n;
    part2(part1)=zeros(size(part1));
    part2 = find(part2);
    part2 = part2(:);
    cut = spaugment(A(part1,part2),1);
    cutxy = xy([part1; part2],:);

    clf reset
    colordef(gcf,'black')
    if size(xy,2) == 2
        axis([min(xy(:,1)) max(xy(:,1)) min(xy(:,2)) max(xy(:,2))]);
    else
        axis([min(xy(:,1)) max(xy(:,1)) min(xy(:,2)) max(xy(:,2)) ...
            min(xy(:,3)) max(xy(:,3))]); 
    end;

    axis equal;
    axis off;

    hold on
    if length(part1) > 0 & length(part2) > 0
        h_cut = gplotg(cut,cutxy,'-');
        set(h_cut,'color',color3);
        xlabel([int2str(cutsize(A,part1)) ' cut edges'],'visible','on');
    else
        xlabel('0 cut edges','visible','on');
    end;
    if length(part1) > 0 
        h_part1 = gplotg(A(part1,part1),xy(part1,:),'-');
        set(h_part1,'color',color1);
        if n < 500,
            if size(xy,2) == 2
                set(plot(xy(part1,1),xy(part1,2),'o'),'color',color1);
            else
                set(plot3(xy(part1,1),xy(part1,2),xy(part1,3),'o'),'color',color1);
            end;
        end;
    end;
    if length(part2) > 0 
        h_part2 = gplotg(A(part2,part2),xy(part2,:),'-');
        set(h_part2,'color',color2);
        if n < 500,
            if size(xy,2) == 2
                set(plot(xy(part2,1),xy(part2,2),'o'),'color',color2);
            else
                set(plot3(xy(part2,1),xy(part2,2),xy(part2,3),'o'),'color',color2);
            end;
        end;
    end;
    hold off
end
