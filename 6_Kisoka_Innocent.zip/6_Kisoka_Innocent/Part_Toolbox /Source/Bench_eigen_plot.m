%% Visualize information from the eigenspectrum of the graph Laplacian
% HPC Course at USI and ETH Zurich

% Add necessary paths
addpaths_GP;

% Graphical output at bisection level
picture = 0;

% List of graph files to process
graph_files = {'airfoil1.mat', '3elt.mat', 'barth4.mat', 'mesh3e1.mat', 'crack.mat'};

% Loop through all graph files
for i = 1:length(graph_files)
    % Load the graph
    load(graph_files{i});
    W = Problem.A;
    coords = Problem.aux.coord;

    % Remove self-loops from the adjacency matrix
    W(1:size(W, 1) + 1:end) = 0;  % Set diagonal elements to zero

    % Step 1: Construct the graph Laplacian
    adj = graph(W);
    lapl = laplacian(adj);

    % Step 2: Compute eigenvectors associated with the smallest eigenvalues
    [ev, lam] = eigs(lapl, 3, 'smallestreal');
    disp(['Eigenvalues for ', graph_files{i}, ':']);
    disp(diag(lam));

    % Step 3: Perform spectral bisection using the Fiedler vector
    second_ev = ev(:, 2);
    [p1, p2] = bisection_spectral(W, coords, 0);

    % Step 4: Visualizations

    %% i. Plot the first and second eigenvectors
    figure;
    plot(1:size(W, 1), ev(:, 1), '-b', 'LineWidth', 1.5); hold on;
    plot(1:size(W, 1), ev(:, 2), '-r', 'LineWidth', 1.5);
    yline(median(ev(:, 2)), '--k', 'LineWidth', 1);
    legend('Smallest EV', 'Fiedler EV', 'Fiedler Median');
    title(['Eigenvectors of Graph Laplacian - ', graph_files{i}]);
    xlabel('Node Index'); ylabel('Eigenvector Value');
    saveas(gcf, strcat('./eigenvectors_', graph_files{i}, '.png'));

    %% ii. Visualize the second eigenvector projected on the graph
    N = size(W, 1);
    zbounds = [min(ev(:, 2)), max(ev(:, 2))];
    figure;
    gplotpart_proj(W, [coords, zeros(length(coords), 1)], zbounds, p1, [0.3, 0.3, 0.3], 'black');
    hold on;
    scatter3(coords(:, 1), coords(:, 2), ev(:, 2), 80 * ones(N, 1), ev(:, 2), '.');
    colorbar;
    title(['Second Eigenvector Projection - ', graph_files{i}]);
    xlabel('X'); ylabel('Y'); zlabel('Fiedler Vector Value');
    saveas(gcf, strcat('./projection_', graph_files{i}, '.png'));

    %% iii. Spectral bi-partitioning results using spectral coordinates
    figure;
    gplotpart(W, [-ev(:, 2), ev(:, 3)], p1, [0.4, 0.4, 0.4], [1, 1, 1]);
    title(['Spectral Bipartitioning (Spectral Coordinates) - ', graph_files{i}]);
    xlabel('Spectral Coord 1 (v2)'); ylabel('Spectral Coord 2 (v3)');
    saveas(gcf, strcat('./spectral_bipartition_', graph_files{i}, '.png'));

    figure;
    gplotpart(W, coords, p1, [0.4, 0.4, 0.4], [1, 1, 1]);
    title(['Spectral Bipartitioning (Spatial Coordinates) - ', graph_files{i}]);
    xlabel('X'); ylabel('Y');
    saveas(gcf, strcat('./spatial_bipartition_', graph_files{i}, '.png'));
end

%% Supporting Functions
function addpaths_GP()
    % Add paths to graph processing functions
    addpath('./Source');
    addpath('./Graphs');
end

function [p1, p2] = bisection_spectral(W, coords, verbose)
    % Perform spectral bisection
    W(1:size(W, 1) + 1:end) = 0; % Ensure no self-loops
    lapl = laplacian(graph(W));
    [ev, ~] = eigs(lapl, 2, 'smallestreal');
    second_ev = ev(:, 2);
    median_val = median(second_ev);
    p1 = find(second_ev <= median_val);
    p2 = find(second_ev > median_val);

    if verbose
        fprintf('Partition sizes: %d (p1), %d (p2)\n', length(p1), length(p2));
    end
end