function [cut_recursive, cut_kway] = Bench_metis()
warning('off', 'MATLAB:HandleGraphics:ObsoletedProperty:Colordef');

    % Compare recursive bisection and direct k-way partitioning
    % using METIS 5.0.2.

    % Add necessary paths
    addpaths_GP;

    % Graphs in question
    cases = {'usroads.mat', 'luxembourg_osm.mat'};
    names = {'usroads', 'luxembourg'};
    partitions = [16, 32]; % Number of partitions

    % Initialize results storage
    num_cases = length(cases);
    num_partitions = length(partitions);
    cut_recursive = zeros(num_cases, num_partitions);
    cut_kway = zeros(num_cases, num_partitions);

    % Load and process graphs
    fprintf('\n\n Report Cases         Nodes     Edges\n');
    fprintf(repmat('-', 1, 45));
    fprintf('\n');

    for c = 1:num_cases
        fprintf('%s', cases{c});
        sparse_matrix = load(cases{c});
        params = Initialize_case(sparse_matrix);
        W = params.Adj;  % Adjacency matrix
        coords = params.coords;  % Coordinates for visualization

        fprintf(' %10d %10d\n', params.numberOfVertices, params.numberOfEdges);

        % Recursive and K-way partitioning
        for p_idx = 1:num_partitions
            p = partitions(p_idx);

            % Recursive bisection
            [map_recursive, edgecut_recursive] = metismex('PartGraphRecursive', W, p);
            cut_recursive(c, p_idx) = edgecut_recursive;

            % Visualization for 32 partitions
            if p == 32
                figure;
                gplotmap(W, coords, map_recursive);
                title(sprintf('Recursive Bisection (%d partitions) - %s', p, names{c}));
                saveas(gcf, sprintf('./%d_recursive_%s.png', p, names{c}));
            end

            % Direct k-way partitioning
            [map_kway, edgecut_kway] = metismex('PartGraphKWay', W, p);
            cut_kway(c, p_idx) = edgecut_kway;

            % Visualization for 32 partitions
            if p == 32
                figure;
                gplotmap(W, coords, map_kway);
                title(sprintf('Direct K-way Partitioning (%d partitions) - %s', p, names{c}));
                saveas(gcf, sprintf('./%d_kway_%s.png', p, names{c}));
            end
        end
    end

    % Display results table
    fprintf('\n\nTable 3: Comparing the number of cut edges\n');
    fprintf('%-15s %10s %10s %10s %10s\n', 'Graph', 'Recursive-16', 'Recursive-32', 'KWay-16', 'KWay-32');
    for c = 1:num_cases
        fprintf('%-15s %10d %10d %10d %10d\n', names{c}, ...
            cut_recursive(c, 1), cut_recursive(c, 2), cut_kway(c, 1), cut_kway(c, 2));
    end
end
