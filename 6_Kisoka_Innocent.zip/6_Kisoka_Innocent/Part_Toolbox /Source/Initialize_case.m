function params = Initialize_case(SM_case)
% Initialize graph parameters from the sparse matrix case

% Check if the adjacency matrix exists in the file structure
if isfield(SM_case, 'Problem') && isfield(SM_case.Problem, 'A')
    params.Adj = SM_case.Problem.A; % Adjacency matrix
elseif isfield(SM_case, 'A')
    params.Adj = SM_case.A; % Alternative field for adjacency matrix
elseif isfield(SM_case, 'adjacency')
    params.Adj = SM_case.adjacency; % Handle other naming conventions
else
    error('The provided case does not have a valid adjacency matrix (Problem.A, A, or adjacency).');
end

% Convert adjacency to incidence matrix
params.Inc = adjacency_to_incidence(params.Adj);

% Get the number of edges and vertices
params.numberOfEdges = size(params.Inc, 1);
params.numberOfVertices = size(params.Inc, 2);

% Check for coordinates (if available)
if isfield(SM_case, 'Problem') && isfield(SM_case.Problem, 'aux') && ...
   isfield(SM_case.Problem.aux, 'coord')
    params.coords = SM_case.Problem.aux.coord;
elseif isfield(SM_case, 'coord')
    params.coords = SM_case.coord;
else
    params.coords = []; % Assign an empty array if coords do not exist
end

end
