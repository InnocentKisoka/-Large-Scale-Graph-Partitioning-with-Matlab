% add necessary paths for the Partitioning Toolbox

addpath ../Datasets/
addpath ../Datasets/Mesh_generation/
addpath ../Datasets/2d_meshes
addpath ../Datasets/Roads/
addpath ../Datasets/Countries_Meshes/csv
addpath ../Datasets/Countries_Meshes/mat
addpath ../External/
addpath Visualization/
